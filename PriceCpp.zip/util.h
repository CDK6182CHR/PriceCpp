
#pragma once
#include"price.h"
//#define ANDROID
SeatType comboIndexToType(int index);



